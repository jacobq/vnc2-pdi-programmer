/*
 * GccApplication1.c
 *
 * Created: 3/8/2019 12:42:37 AM
 * Author : jacob
 */ 

#include <avr/io.h>


int main(void)
{
	PORTA_DIR |= 0x01;
    while (1) 
    {
		PORTA_OUT |= 0x01;
		PORTA_OUT &= 0x00;
    }
}

