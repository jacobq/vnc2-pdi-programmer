const fs = require('fs');

const data_file = "C:\\Users\\jacob\\Documents\\PDI\\C1Trace00003.csv";
const clock_file = "C:\\Users\\jacob\\Documents\\PDI\\C2Trace00003.csv";
const output_file = "C:\\Users\\jacob\\Documents\\PDI\\out-decimated.csv";

// Files look like this:
/*

LECROYWS10,10050,Waveform
Segments,1,SegmentSize,16000002
Segment,TrigTime,TimeSinceSegment1
#1,22-Mar-2019 13:21:22,0
Time,Ampl
-0.032000008418,0.0830234
-0.031999988418,0.0415117
-0.031999968418,-0.0415117

 */


const V = 3.3;
const vol = V * 1/3;
const voh = V * 2/3;

const [clock_csv_records, data_csv_records] = [clock_file, data_file].map(file => {
    console.log(`attempting to read file = ${file}`);
    return fs.readFileSync(file, { encoding: 'utf8' })
        .split(/\r\n/)
});

const last_record = Math.min(clock_csv_records.length, data_csv_records.length) - 1;
console.log(`last_record = ${last_record}`);

const records = [['time (s)', 'PDI_CLK', 'PDI']];
let last_clock_value = null;
let points_left_in_bunch = 0;

for (let i=10; i < last_record; i++) {
    const [time_raw, clock_raw] = clock_csv_records[i].split(',');
    const clock_value = a2d(clock_raw, last_clock_value)
    const clock_changed = clock_value !== last_clock_value;

    if (i % 100000 === 0) {
        console.log(`i = ${i}, records.length = ${records.length}, time_raw = ${time_raw}, clock_raw = ${clock_raw}, clock_value = ${clock_value}, clock_changed = ${clock_changed}`);
    }

	//if (clock_changed) {
	//	points_left_in_bunch = 10;
	//}

    //if (points_left_in_bunch > 0) {
    // take even points only (decimate)
	if (i%2 > 0) {
        const [ time2_raw, data_raw ] = data_csv_records[i].split(',');
        const data_value = a2d(data_raw);
        records.push([
            time_raw,
            //clock_raw,
            //data_raw,
            clock_value,
            data_value,
        ]);
		//points_left_in_bunch--;
    }
	last_clock_value = clock_value;
}

console.log(`Writing ${records.length} records to output file = ${output_file}`);
fs.writeFileSync(output_file, records.map(row => row.join(',')).join('\r\n'));


function a2d(a, last_d = null) {
    if (last_d === null) {
        // First sample -- split in the middle
        return a >= V/2 ? 1 : 0;
    }
    else if (last_d) {
        // Was high -- seeking transition to low
        return a > vol ? 1 : 0;
    }
    else {
        // Was low -- seeking transition to high
        return a < voh ? 0 : 1;
    }
}
